<?php 
/**
 * Blog shortcode
 */

if ( ! function_exists( 'aven_zozo_vc_blog_shortcode' ) ) {
	function aven_zozo_vc_blog_shortcode( $atts, $content = NULL ) { 
		
		$atts = vc_map_get_attributes( 'zozo_vc_blog', $atts );
		extract( $atts );

		$output = '';
		global $post;
		
		// Include categories
		$include_categories = ( '' != $include_categories ) ? $include_categories : '';
		$include_categories = ( 'all' == $include_categories ) ? '' : $include_categories;
		if( $include_categories ) {
			$include_categories = explode( ',', $include_categories );
			if ( ! empty( $include_categories ) && is_array( $include_categories ) ) {
				$include_categories = array(
					'taxonomy'	=> 'category',
					'field'		=> 'slug',
					'terms'		=> $include_categories,
					'operator'	=> 'IN',
				);
			} else {
				$include_categories = '';
			}
		}
				
		// Exclude categories
		if( $exclude_categories ) {
			$exclude_categories = explode( ',', $exclude_categories );
			if ( ! empty( $exclude_categories ) && is_array( $exclude_categories ) ) {
				$exclude_categories = array(
						'taxonomy'	=> 'category',
						'field'		=> 'slug',
						'terms'		=> $exclude_categories,
						'operator'	=> 'NOT IN',
					);
			} else {
				$exclude_categories = '';
			}
		}
				
		if( ( is_front_page() || is_home() ) ) {
			$paged = (get_query_var('paged')) ? get_query_var('paged') : ((get_query_var('page')) ? get_query_var('page') : 1);
		} else {
			$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
		}
		
		$query_args = array(
						'posts_per_page'	=> $posts,
						'paged' 			=> $paged,
						'orderby' 		 	=> 'date',
						'order' 		 	=> 'DESC',
					  );
					  		
		$query_args['tax_query'] 	= array(
										'relation'	=> 'AND',
										$include_categories,
										$exclude_categories );
		
		$blog_query = new WP_Query( $query_args );
		
		$post_class = $container_class = $scroll_type = $scroll_type_class = '';
		$post_type_layout = $excerpt_limit = '';
		
		$data_attr = '';
		
		$column_width = '';
		$display_mode = '';
		
		// Grid Style
		if( $layout == 'grid' ) {
			$container_class = 'zozo-isotope-layout ';
			if( $columns != '' ) {
				if( $columns == 'two' ) {
					$container_class .= 'grid-layout grid-col-2';
					$grid_columns_num = 2;
				} elseif( $columns == 'three' ) {
					$container_class .= 'grid-layout grid-col-3';
					$grid_columns_num = 3;
				} elseif( $columns == 'four' ) {
					$container_class .= 'grid-layout grid-col-4';
					$grid_columns_num = 4;
				}
			}
			$post_class = 'isotope-post grid-posts ';
			$column_width = 12 / $grid_columns_num;
			$post_class .= 'post-iso-w' . $column_width;
			$post_class .= ' post-iso-h' . $column_width;
			
			$image_size = 'aven-blog-medium';
			$page_type_layout = 'grid';
			$display_mode = 'isotope';
			if( isset( $excerpt_length ) && $excerpt_length == '' ) {
				$excerpt_limit = aven_zozo_get_theme_option( 'zozo_blog_excerpt_length_grid' );
			} else {
				$excerpt_limit = $excerpt_length;
			}
			$data_attr = ' data-layout=masonry data-columns='. $grid_columns_num .' data-gutter=30';
		}
		// Large Style
		elseif( $layout == 'large' ) {
			$container_class = 'large-layout';
			$post_class = 'large-posts';
			$image_size = 'aven-blog-large';
			$post_type_layout = 'large';
			if( isset( $excerpt_length ) && $excerpt_length == '' ) {
				$excerpt_limit = aven_zozo_get_theme_option( 'zozo_blog_excerpt_length_large' );
			} else {
				$excerpt_limit = $excerpt_length;
			}
		}
		// List Style
		elseif( $layout == 'list' ) {
			$container_class = 'list-layout';
			$post_class = 'list-posts clearfix';	
			$image_size = 'aven-blog-medium';
			$page_type_layout = 'list';
			if( isset( $excerpt_length ) && $excerpt_length == '' ) {
				$excerpt_limit = aven_zozo_get_theme_option( 'zozo_blog_excerpt_length_list' );
			} else {
				$excerpt_limit = $excerpt_length;
			}
		}
		// Metro Style
		elseif( $layout == 'metro' ) {
			$container_class = 'zozo-isotope-layout ';			
			if( isset( $columns ) && $columns != '' ) {
				if( $columns == 'two' ) {
					$container_class .= 'metro-layout metro-col-2';
					$metro_columns_num = 2;
				} elseif ( $columns == 'three' ) {
					$container_class .= 'metro-layout metro-col-3';
					$metro_columns_num = 3;
				} elseif ( $columns == 'four' ) {
					$container_class .= 'metro-layout metro-col-4';
					$metro_columns_num = 4;
				}
			}
			
			$post_class = 'isotope-post metro-posts ';
			$column_width = 12 / $metro_columns_num;
			$post_class .= 'post-iso-w' . $column_width;
			$post_class .= ' post-iso-h' . $column_width;
			
			$thumb_width = 530;
			$thumb_height = null;
			$page_type_layout = 'metro';
			$display_mode = 'isotope';
			if( isset( $gutter ) && $gutter == '' ) {
				$gutter = 0;
			}
			$data_attr = ' data-layout=masonry data-columns='. $metro_columns_num .' data-gutter='. $gutter .'';
		}
		
		if( $pagination == "infinite" ) {
			$scroll_type = "infinite";
			if( isset( $display_mode ) && $display_mode == 'isotope' ) {
				$scroll_type_class = " posts-isotope-infinite";
			} else {
				$scroll_type_class = " posts-infinite";
			}
		} elseif( $pagination == "pagination" ) {
			$scroll_type = "pagination";
			$scroll_type_class = " posts-pagination";
		}
		
		// Meta 		
		$meta_array = array();
		$meta_array = array( 'more' 	=> $hide_morelink,
							'thumbnail' => $hide_thumbnail,
							'author' 	=> $hide_author,
							'comments' 	=> $hide_comments, 
							'date' 		=> $hide_date,
							'categories' => $hide_categories );

		// Animation					
		$animation = array();
		
		if( $pagination == "infinite" ) {
			$animation = array( 'animation' 	=> 'bottom-t-top',
								'delay' 		=> '200' );
		}
		
		$post_count = 1;
		
		// Classes
		$main_classes = '';
		
		if( isset( $classes ) && $classes != '' ) {
			$main_classes .= ' ' . $classes;
		}
		
		if( $blog_query->have_posts() ) {
		
			$output = '<div id="zozo-blog-posts-container" class="zozo-blog-posts-wrapper zozo-isotope-grid-system'.$main_classes.'">';
			
				if( isset( $display_mode ) && $display_mode == 'isotope' ) {
					$output .= '<div class="zozo-isotope-wrapper blog-isotope-wrapper">';
				}
							
				$output .= '<div id="archive-posts-container" class="zozo-posts-container '. esc_attr($container_class . $scroll_type_class) .' clearfix"'. $data_attr .'>';
				
				while($blog_query->have_posts()) : $blog_query->the_post();
				
					$post_id = get_the_ID();
											
					if( isset( $layout ) && ( $layout == 'large' || $layout == 'list' ) ) {
						$output .= aven_zozo_output_blog_large_layout( $post_id, $post_class, $image_size, $excerpt_limit, $meta_array, $layout );
					} 
					
					else if( isset( $layout ) && $layout == 'grid' ) {
						$output .= aven_zozo_output_blog_grid_layout( $post_id, $post_class, $image_size, $excerpt_limit, $meta_array, $animation );
					}
					
					else if( isset( $layout ) && $layout == 'metro' ) {
						$output .= aven_zozo_output_blog_metro_layout( $post_id, $post_class, $thumb_width, $thumb_height, $meta_array, $animation, $gutter );
					}
					
					$post_count++;

				endwhile;
				
				$output .= '</div>';
				
				if( isset( $display_mode ) && $display_mode == 'isotope' ) {
					$output .= '</div>';
				}
			
				if( $pagination != "hide" ) {
					$output .= '<div class="zozo-blog-pagination-wrapper">';
					$output .= aven_zozo_pagination( $blog_query->max_num_pages, $scroll_type );
					$output .= '</div>';
				}
			
			$output .= '</div>';
			
		}
		
		wp_reset_postdata();
		
		return $output;
	}
}

if ( ! function_exists( 'aven_zozo_vc_blog_shortcode_map' ) ) {
	function aven_zozo_vc_blog_shortcode_map() {
		
		vc_map( 
			array(
				"name"					=> esc_html__( "Blog", "aven" ),
				"description"			=> esc_html__( "Show your blog posts in different styles.", 'aven' ),
				"base"					=> "zozo_vc_blog",
				"category"				=> esc_html__( "Theme Addons", "aven" ),
				"icon"					=> "zozo-vc-icon",
				"params"				=> array(					
					array(
						'type'			=> 'textfield',
						'heading'		=> esc_html__( 'Extra Class', "aven" ),
						'param_name'	=> 'classes',
						'value' 		=> '',
					),
					array(
						"type"			=> "textfield",
						"heading"		=> esc_html__( "Posts per Page", "aven" ),
						"admin_label" 	=> true,
						"param_name"	=> "posts",						
					),
					array(
						'type'			=> 'textfield',
						'heading'		=> esc_html__( 'Include Categories', 'aven' ),
						'param_name'	=> 'include_categories',
						'admin_label'	=> true,
						'description'	=> esc_html__('Enter the slugs of a categories (comma seperated) to pull posts from or enter "all" to pull recent posts from all categories. Example: category-1, category-2.','aven'),
					),
					array(
						'type'			=> 'textfield',
						'heading'		=> esc_html__( 'Exclude Categories', 'aven' ),
						'param_name'	=> 'exclude_categories',
						'admin_label'	=> true,
						'description'	=> esc_html__('Enter the slugs of a categories (comma seperated) to exclude. Example: category-1, category-2.','aven'),
					),
					array(
						"type"			=> 'dropdown',
						"heading"		=> esc_html__( "Blog Layout", "aven" ),
						"param_name"	=> "layout",
						"admin_label" 	=> true,
						"group"			=> esc_html__( "Layout", "aven" ),
						"value"			=> array(
							esc_html__( "Large Layout", "aven" )		=> "large",
							esc_html__( "List Layout", "aven" )		=> "list",
							esc_html__( "Grid Layout", "aven" )		=> "grid",
							esc_html__( "Metro Style", "aven" )		=> "metro" ),
					),
					array(
						"type"			=> 'dropdown',
						"heading"		=> esc_html__( "Blog Columns", "aven" ),
						"param_name"	=> "columns",
						"admin_label" 	=> true,
						"group"			=> esc_html__( "Layout", "aven" ),
						"value"			=> array(
							esc_html__( "2 Columns", "aven" )		=> "two",
							esc_html__( "3 Columns", "aven" )		=> "three",
							esc_html__( "4 Columns", "aven" )		=> "four" ),
						'dependency'	=> array(
							'element'	=> 'layout',
							'value'		=> array( 'grid', 'metro' ),
						),
					),
					array(
						"type"			=> "textfield",
						"heading"		=> esc_html__( "Excerpt Limit", "aven" ),
						"param_name"	=> "excerpt_length",
						"group"			=> esc_html__( "Layout", "aven" ),
						"description" 	=> esc_html__( "Enter excerpt length", "aven" ),
						'dependency'	=> array(
							'element'	=> 'layout',
							'value'		=> array( 'large', 'list', 'grid' ),
						),
					),
					array(
						"type"			=> "textfield",
						"heading"		=> esc_html__( "Items Spacing", "aven" ),
						"param_name"	=> "gutter",
						"group"			=> esc_html__( "Layout", "aven" ),
						"description" 	=> esc_html__( "Enter gap size between items. Only enter number Ex: 10", "aven" ),
						'dependency'	=> array(
							'element'	=> 'layout',
							'value'		=> 'metro',
						),
					),
					array(
						"type"			=> 'dropdown',
						"heading"		=> esc_html__( "Hide Thumbnail", "aven" ),
						"param_name"	=> "hide_thumbnail",
						"value"			=> array(
							esc_html__( "No", "aven" )	=> 0,
							esc_html__( "Yes", "aven" )	=> 1 ),
						'dependency'	=> array(
							'element'	=> 'layout',
							'value'		=> array( 'large', 'list', 'classic', 'grid', 'masonry' ),
						),
					),
					array(
						"type"			=> 'dropdown',
						"heading"		=> esc_html__( "Hide Author", "aven" ),
						"param_name"	=> "hide_author",
						"value"			=> array(
							esc_html__( "No", "aven" )	=> 0,
							esc_html__( "Yes", "aven" )	=> 1 ),
					),
					array(
						"type"			=> 'dropdown',
						"heading"		=> esc_html__( "Hide Comments", "aven" ),
						"param_name"	=> "hide_comments",
						"value"			=> array(
							esc_html__( "No", "aven" )	=> 0,
							esc_html__( "Yes", "aven" )	=> 1 ),
					),
					array(
						"type"			=> 'dropdown',
						"heading"		=> esc_html__( "Hide Date", "aven" ),
						"param_name"	=> "hide_date",
						"value"			=> array(
							esc_html__( "No", "aven" )	=> 0,
							esc_html__( "Yes", "aven" )	=> 1 ),
					),
					array(
						"type"			=> 'dropdown',
						"heading"		=> esc_html__( "Hide Categories", "aven" ),
						"param_name"	=> "hide_categories",
						"value"			=> array(
							esc_html__( "No", "aven" )	=> 0,
							esc_html__( "Yes", "aven" )	=> 1 ),
					),
					array(
						"type"			=> 'dropdown',
						"heading"		=> esc_html__( "Hide Read More Link", "aven" ),
						"param_name"	=> "hide_morelink",
						"value"			=> array(
							esc_html__( "No", "aven" )	=> 0,
							esc_html__( "Yes", "aven" )	=> 1 ),
					),
					array(
						"type"			=> 'dropdown',
						"heading"		=> esc_html__( "Pagination", "aven" ),
						"param_name"	=> "pagination",
						"group"			=> esc_html__( "Layout", "aven" ),
						"value"			=> array(
							esc_html__( "Hide", "aven" )				=> "hide",
							esc_html__( "Pagination", "aven" )		=> "pagination",
							esc_html__( "Infinite Scroll", "aven" )	=> "infinite" ),
					),
				)
			) 
		);
	}
}
add_action( 'vc_before_init', 'aven_zozo_vc_blog_shortcode_map' );