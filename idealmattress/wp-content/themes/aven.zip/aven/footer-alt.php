<?php
/**
 * The Alternate Footer for our theme.
 *
 * The template for displaying the footer.
 *
 * @package Zozothemes
 */
?>
	</div><!-- #main -->
</div>
<?php wp_footer(); ?>

</body>
</html>