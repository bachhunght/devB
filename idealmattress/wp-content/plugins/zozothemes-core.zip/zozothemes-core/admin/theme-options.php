<?php
/**
 * Theme Options
 */

require_once( ZOZO_CORE_ADMIN . '/functions.php' );

// include redux framework core functions
require_once( ZOZO_CORE_ADMIN . '/ReduxCore/framework.php' );