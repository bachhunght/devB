<?php
/** 
 * Footer template 
 */
?>
    <!-- Footer part -->
    <footer class="main-footer">
        <div class="container">
            <h2>Contact</h2>
            <ul class="footer-contact-info">
                <li>
                    <p><?php the_field( 'address', 'options' ); ?></p>
                </li>
                <li>
                    <a href="mailto:<?php the_field( 'email', 'options' );?>"><?php the_field( 'email', 'options' );?></a>
                    
                    <div class="footer-links">
                        <?php while( have_rows( 'social_links', 'options' ) ): the_row(); ?>
                            <a href="<?php echo get_sub_field( 'link' ); ?>" target="_blank">
                                <?php $icon = get_sub_field( 'image' ); ?> 
                                <img src="<?php echo $icon['url'];?>" alt="facebook">
                            </a>
                        <?php endwhile; ?>
                    </div>
                </li>
                <li>
                    <p>Booking & Installation (Metro Only)</p>
                    <a href="tel:<?php the_field( 'contact_no', 'options' );?>"><?php the_field( 'contact_no', 'options' );?></a>
                </li>
            </ul>
        </div>
    </footer>


    <?php wp_footer(); ?>
<script>
$(document).ready(function(){
alert("Hello1243");
});
</script>

    </body>
</html>