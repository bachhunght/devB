<?php
/** 
 * Header template 
 */
?>

<!DOCTYPE HTML >
<html <?php language_attributes(); ?> class="no-js no-svg">
    <head>
        <meta charset="<?php bloginfo( 'charset' ); ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
        <meta name="description" content="" /> 
        <meta name="keywords" content="">
        <meta name="SKYPE_TOOLBAR" content="SKYPE_TOOLBAR_PARSER_COMPATIBLE" />
        <link rel="profile" href="http://gmpg.org/xfn/11">
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet"> 
        <?php wp_head(); ?>
    </head>
    <body <?php body_class(); ?>>
        <div class="top">
            <div class="go-to-top">
                <div class="go-to-top-arrow"></div>
            </div>
        </div>
        
        <!-- Header start -->
        <header class="main-header">
            <div class="container">
                <div class="logo">
                    <a href="<?php echo site_url(); ?>">
                        <?php $logo = get_field( 'logo', 'options' );?>
                        <img src="<?php echo $logo['url'];?>" alt="<?php echo $logo['alt'];?>">
                    </a>
                </div>
                <div class="right-header">
                    <div class="header-contact">
                        <p>Call now for a <a href="tel:<?php the_field( 'contact_no', 'options' );?>"> FREE QUOTE <?php the_field( 'contact_no', 'options' );?></a></p>
                        <div class="header-links">
                            <?php while( have_rows( 'social_links', 'options' ) ): the_row(); ?>
                                <a href="<?php echo get_sub_field( 'link' ); ?>" target="_blank">
                                    <?php $icon = get_sub_field( 'image' ); ?> 
                                    <img src="<?php echo $icon['url'];?>" alt="<?php echo $icon['alt'];?>">
                                </a>
                            <?php endwhile; ?>
                        </div>
                    </div>
                    <a href="javascript:void(0)" class="hb-menu">
                        <span></span>
                    </a>
                    
                    <?php 
                        if ( has_nav_menu( 'top' ) ) {
                            wp_nav_menu( array(
                                'container' => 'nav',
                                'container_class' => 'main-nav',
                                'theme_location' => 'top'
                            ) ); 
                        }
                    ?>
                </div>
            </div>  
        </header>