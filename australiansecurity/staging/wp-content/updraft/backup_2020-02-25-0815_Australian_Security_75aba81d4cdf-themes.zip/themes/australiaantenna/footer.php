<?php
/** 
 * Footer template 
 */
?>
    <!-- Footer part -->
    <footer class="main-footer">
        <div class="container">
<p class="footer-title">Contact</p>
            <ul class="footer-contact-info">
                <li>
                    <p><?php the_field( 'address', 'options' ); ?></p>
                    <p style="margin-top: 15px;">Booking & Installation (Metro Only)</p>
                    <a class="phone-number-footer" href="tel:<?php the_field( 'contact_no', 'options' );?>"><?php the_field( 'contact_no', 'options' );?></a>
                </li>
                <li>
                    <a class="email-footer" href="mailto:sales@australiansecurity.com.au" style="clear: both;display: block;">sales@australiansecurity.com.au</a><br />
					
					<span style="font-weight: bold; margin-bottom:10px; display:none;">Melbourne's best reviewed <br />Antenna Company</span>

                    
                    
                </li>
                <li style="color: white; font-size: 14px;">

<a href="https://www.australiansecurity.com.au/sitemap/" title=""><strong>Sitemap</strong></a>


                </li>
            </ul>
        </div>
    </footer>


    <?php wp_footer(); ?>
	<?php echo do_shortcode( '[brb_collection id="1314"]' ); ?>


    </body>
</html>