<?php

namespace YoastSEO_Vendor\Psr\Log;

class InvalidArgumentException extends \InvalidArgumentException
{
}
