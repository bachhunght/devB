<?php
/** 
 * Footer template 
 */
?>
    <!-- Footer part -->
    <footer class="main-footer">
        <div class="container">
<p class="footer-title">Contact</p>
            <ul class="footer-contact-info">
                <li>
                    <p><?php the_field( 'address', 'options' ); ?></p>
                    <p style="margin-top: 15px;">Booking & Installation (Metro Only)</p>
                    <a class="phone-number-footer" href="tel:<?php the_field( 'contact_no', 'options' );?>"><?php the_field( 'contact_no', 'options' );?></a>
                </li>
                <li>
                    <a class="email-footer" href="mailto:<?php the_field( 'email', 'options' );?>"><?php the_field( 'email', 'options' );?></a>
                    
                    <div class="footer-links">
                        <?php while( have_rows( 'social_links', 'options' ) ): the_row(); ?>
                            <a href="<?php echo get_sub_field( 'link' ); ?>" target="_blank" class="social-media-icons-footer">
                                <?php $icon = get_sub_field( 'image' ); ?> 
                                <img class="social-media-icons-footer" src="<?php echo $icon['url'];?>" alt="<?php echo $icon['title'];?>">
                            </a>
                        <?php endwhile; ?>
                    </div>
                </li>
                <li style="color: white; font-size: 14px;">
<span style="font-weight: bold; margin-bottom:10px; display:block;">Melbourne's best reviewed <br />Antenna Company</span>

<div itemscope itemtype="http://schema.org/Review">
<a itemprop="url" href="https://business.google.com/reviews/l/13756202131129109060"><div itemprop="name">
<img width="100" src="https://www.australianantennas.com.au/wp-content/uploads/2019/02/google-reviews-logo.png"><strong style="display:none;">Customer Reviews</strong></div>
</a>
<div style="display:none;" itemprop="reviewBody">Google My Business</div>
<div style="display:none;" itemprop="author" itemscope itemtype="http://schema.org/Person">
Written by: <span itemprop="name">Customers</span></div>
<meta itemprop="datePublished" content="2018-06-22">
<span>Date published: 22/06/2018</span>
<div itemprop="reviewRating" itemscope itemtype="http://schema.org/Rating">
<meta itemprop="worstRating" content="1"><span itemprop="ratingValue">4.8</span> / <span itemprop="bestRating">5</span> stars</div>
</br>
<a href="https://www.australianantennas.com.au/sitemap/" title=""><strong>Sitemap</strong></a>
</div>


</div>
                </li>
            </ul>
        </div>
    </footer>


    <?php wp_footer(); ?>


    </body>
</html>